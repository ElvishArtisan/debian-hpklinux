/******************************************************************************
 Array initializer for PCI card IDs

    Copyright (C) 1997-2017  AudioScience Inc. <support@audioscience.com>

    This program is free software; you can redistribute it and/or modify
    it under the terms of version 2 of the GNU General Public License as
    published by the Free Software Foundation;

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
*******************************************************************************/

/*NOTE: when adding new lines to this header file
  they MUST be grouped by HPI entry point.
*/

#ifdef HPI_BUILD_INCLUDE_HPI6700
{
HPI_PCI_VENDOR_ID_TI, HPI_PCI_DEV_ID_DM8147,
	    HPI_PCI_VENDOR_ID_AUDIOSCIENCE, PCI_ANY_ID, 0, 0,
	    (DRIVER_DATA_TYPE)HPI6700_adapter_init},
#endif
#ifdef HPI_BUILD_INCLUDE_HPI6205
{
HPI_PCI_VENDOR_ID_TI, HPI_PCI_DEV_ID_DSP6205,
	    HPI_PCI_VENDOR_ID_AUDIOSCIENCE, PCI_ANY_ID, 0, 0,
	    (DRIVER_DATA_TYPE)HPI6205_adapter_init},
#endif
#ifdef HPI_BUILD_INCLUDE_HPI6000
{
HPI_PCI_VENDOR_ID_TI, HPI_PCI_DEV_ID_PCI2040,
	    HPI_PCI_VENDOR_ID_AUDIOSCIENCE, PCI_ANY_ID, 0, 0,
	    (DRIVER_DATA_TYPE)HPI6000_adapter_init},
#endif
{0}
