#!/usr/bin/env python

# run "python setup.py install"
# add "--home ~" to install just for yourself.
# You will need ~/lib/python in your PYTHONPATH.

from setuptools import setup

setup(
    name = "hpi",
    version = "2.0",
    url = 'http://audioscience.com',
    author = 'AudioScience Inc.',
    author_email = 'support@audioscience.com',
    packages = ['audioscience'],
    scripts=['hpicontrol', 'hpimixer', 'hpisave']
)
