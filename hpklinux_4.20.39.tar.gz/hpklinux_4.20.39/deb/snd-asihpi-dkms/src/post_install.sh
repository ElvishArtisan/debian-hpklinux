#!/bin/sh
# DKMS post-install script
# Reload driver when new one is installed

if [ $(uname -r) != $kernelver ] ; then
  # don't try to reload module when not installing for
  # current kernel
  exit 0
fi

if (lsmod | grep 'asihpi' -q) ; then
  modnames=$(lsmod | awk '/^asihpi|^snd_asihpi/ {print $1}')
  for modname in $modnames ; do
      echo "Unload $modname"
      rmmod $modname || {
		  echo "Failed - module still in use?"
		  exit 1
	  }
  done
fi

# Only get here if all loaded modules can be unloaded
# Need to depmod so new module is used by modprobe
depmod -a
modprobe -v snd-asihpi && echo "OK" || echo "Failed"
