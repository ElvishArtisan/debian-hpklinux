#!/bin/sh

if test -d "/lib/modules/`uname -r`/build" -o -L "/lib/modules/`uname -r`/build"; then
  kernelbuild="/lib/modules/`uname -r`/build"
elif test -d "/lib/modules/`uname -r`/source" -o -L "/lib/modules/`uname -r`/source"; then
  kernelbuild="/lib/modules/`uname -r`/source"
fi

if [ ! -z "${kernelbuild}" ]; then
	echo $(realpath ${kernelbuild})
fi
