#!/bin/sh

if test -d /lib/firmware ; then
		FIRMWAREDIR="/lib/firmware"
elif test -d /lib/hotplug/firmware ; then
		FIRMWAREDIR="/lib/hotplug/firmware"
elif test -d /usr/lib/hotplug/firmware ; then
		FIRMWAREDIR="/usr/lib/hotplug/firmware"
else
		FIRMWAREDIR="/lib/firmware"
fi

echo ${FIRMWAREDIR}
