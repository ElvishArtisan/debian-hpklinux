# This directory is the 'audioscience' package
# python bindings for hpi and asx libraries
