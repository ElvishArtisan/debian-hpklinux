/******************************************************************************
 SSX2 virtual multichannel stream functions

Copyright (C) 1997-2017 AudioScience, Inc. All rights reserved.

This software is provided 'as-is', without any express or implied warranty.
In no event will AudioScience Inc. be held liable for any damages arising
from the use of this software.

Permission is granted to anyone to use this software for any purpose,
including commercial applications, and to alter it and redistribute it
freely, subject to the following restrictions:

1. The origin of this software must not be misrepresented; you must not
   claim that you wrote the original software. If you use this software
   in a product, an acknowledgment in the product documentation would be
   appreciated but is not required.
2. Altered source versions must be plainly marked as such, and must not be
   misrepresented as being the original software.
3. This copyright notice and list of conditions may not be altered or removed
   from any source distribution.

AudioScience, Inc. <support@audioscience.com>

( This license is GPL compatible see http://www.gnu.org/licenses/license-list.html#GPLCompatibleLicenses )

******************************************************************************/

#ifndef _HPISSX2_H_
#define _HPISSX2_H_

#include "hpi_internal.h"

#ifdef __cplusplus
/* *INDENT-OFF* */
extern "C" {
/* *INDENT-ON* */
#endif

typedef uint16_t HPI_BOOL;

HPI_BOOL HPI_PreMessageSsx2(HPI_MESSAGE *phm,
			    HPI_RESPONSE *phr, void *hOwner);

void HPI_PostMessageSsx2(HPI_MESSAGE *phm, HPI_RESPONSE *phr, void *hOwner);

void HPI_MessageSsx2(HPI_MESSAGE *phm, HPI_RESPONSE *phr, void *hOwner);

#define HPI_MESSAGE_LOWER_LAYER HPI_MessageSsx2

#ifdef __cplusplus
/* *INDENT-OFF* */
}
/* *INDENT-ON* */
#endif

#endif				/* _HPISSX2_H_ */
